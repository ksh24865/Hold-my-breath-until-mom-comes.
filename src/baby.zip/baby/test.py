import datetime

now = datetime.datetime.now()
print(now.hour)