import pymysql

"""
YOU CAN SIMPLY MAKE, DELETE DATABASE AND TABLE

REQUIREMENTS
    MARIADB, PYMYSQL
    
"""

inn = 0
while(inn != 4):
    print("--------------")
    print("SQL MAKEFILE")
    print("1. MAKE DATABASE")
    print("2. MAKE TABLE")
    print("3. DELETE DATABASE")
    print("4. MAKE WEIGHT TABLE")
    print("--------------")
    inn = input()
    if inn == '1':
        db = pymysql.connect(host='localhost', user = 'root', password='0000', charset='utf8')
        cursor = db.cursor()
        temp = input("DATABASE NAME: ")
        sql = "CREATE DATABASE " + temp + ""
        cursor.execute(sql)
        db.commit()
        db.close()
    elif inn == '2':
        db = pymysql.connect(host="localhost", user="root", passwd="0000", charset = "utf8")
        cursor = db.cursor()
        print("TABLE WIZARD")
        print("this will create table , columns(id(key), temperature, humidity, weight, time)")
        print("Current Databases")
        sql = "show databases"
        cursor.execute(sql)
        result = cursor.fetchall()
        for i in result:
            print(i, end='\n')
        temp = input("Choose DATABASE: ") 
        db = pymysql.connect(host="localhost", user="root", passwd="0000", db = temp, charset = "utf8")
        cursor = db.cursor()
        temp_table = input("TABLE NAME: ")
        sql = "CREATE TABLE " + temp_table + " (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, temperature float(10.2), humidity float(10.2), weight float(10.2), dates DATE)"  
        cursor.execute(sql)
        db.commit()
        db.close()        
    elif inn == '3':
        db = pymysql.connect(host="localhost", user="root", passwd="0000", charset = "utf8")
        cursor = db.cursor()
        print("Current Databases")
        sql = "show databases"
        cursor.execute(sql)
        result = cursor.fetchall()
        for i in result:
            print(i, end='\n')
        temp = input("Choose DATABASE to DELETE: ") 
        sql = "DROP DATABASE " + temp + ""
        cursor.execute(sql)
        print("Current Databases")
        sql = "show databases"
        cursor.execute(sql)
        result = cursor.fetchall()
        for i in result:
            print(i, end='\n')
        
    elif inn == '4':    
        db = pymysql.connect(host="localhost", user="root", passwd="0000", charset = "utf8")
        cursor = db.cursor()
        print("MAKE WEIGHT TABLE(weight, time)")
        print("this will create table , columns(id(key), weight, time)")
        print("Current Databases")
        sql = "show databases"
        cursor.execute(sql)
        result = cursor.fetchall()
        for i in result:
            print(i, end='\n')
        temp = input("Choose DATABASE: ") 
        db = pymysql.connect(host="localhost", user="root", passwd="0000", db = temp, charset = "utf8")
        cursor = db.cursor()
        sql = "CREATE TABLE WEIGHT (id int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, weight float(10.2), dates char(40))"  
        cursor.execute(sql)
        db.commit()
        db.close()        
        
   
   
   
    """
    ////  INSERT DATA  ////
    
    db = pymysql.connect(host='localhost', user = 'root', password='0000', db = '!DBNAME!', charset='utf8')
    cursor = db.cursor()


    sql = '''CREATE TABLE !TABLENAME_! (
    weight int(11) UNSIGNED NOT NULL);'''

    cursor.execute(sql)


    db.commit()
    db.close()
    """